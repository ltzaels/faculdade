# opções válidas para o presidente
nome_Pres1 = "Albert Einstein"
nome_Pres2 = "Isaac Newton"
nome_Pres3 = "Stephen Hawking"
nome_Pres4 = "Bill Gates"
nome_Pres5 = "Steve Jobs"

# opções válidas para o governador
nome_Gov1 = "Will Smith Ragatanga"
nome_Gov2 = "Bruce Batman da Silva"
nome_Gov3 = "Tony Stark Carvalho Pereira"
nome_Gov4 = "Wesley Safadão"
nome_Gov5 = "Chimbinha da Joelma Ferreira"

def listar(): # fução para listar os candidatos opção 1 do menu
    print("\n")
    print("╔════════════Lista de candidatos════════════╗")
    print("\n")
    print(" ═══════════════ Governador ══════════════")
    print("\n")
    print(" Candidato(a) 1: %s" % (nome_Gov1))
    print(" Candidato(a) 2: %s" % (nome_Gov2))
    print(" Candidato(a) 3: %s" % (nome_Gov3))
    print(" Candidato(a) 4: %s" % (nome_Gov4))
    print(" Candidato(a) 5: %s" % (nome_Gov5))
    print("\n")
    print(" ═══════════════ Presidente ═══════════════")
    print("\n")
    print(" Candidato(a) 1: %s" % (nome_Pres1))
    print(" Candidato(a) 2: %s" % (nome_Pres2))
    print(" Candidato(a) 3: %s" % (nome_Pres3))
    print(" Candidato(a) 4: %s" % (nome_Pres4))
    print(" Candidato(a) 5: %s" % (nome_Pres5))
    print("╚═════════════════════════════════════════════╝")

